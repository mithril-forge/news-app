"""
Czech News Crawler Package - A specialized crawler for Czech news websites.

This package provides tools to crawl and extract articles from popular Czech news sites.
It can be used as a command-line tool or imported as a library.

Example usage as a library:
```python
from cz_news import crawl_czech_news

# Get articles from the last 3 days
result = crawl_czech_news(
    recent_days=3,
    max_articles_per_site=10
)

# Access articles by domain
for domain, articles in result.articles_by_domain.items():
    print(f"Found {len(articles)} articles from {domain}")
    for article in articles:
        print(f"- {article.title}")
```
"""

from .crawler import crawl_czech_news
from .models import Article, CrawlResult, CrawlSummary

__all__ = [
    'crawl_czech_news',
    'Article',
    'CrawlResult',
    'CrawlSummary',
]
