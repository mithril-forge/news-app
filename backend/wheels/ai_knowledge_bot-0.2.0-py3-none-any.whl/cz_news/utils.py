#!/usr/bin/env python3
"""
Utility functions for the Czech News Crawler.
Contains helpers for URL normalization and other common operations.
"""

import logging
import re
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("cz_news.utils")


def normalize_url(url: str) -> str:
    """
    Normalize URL by removing common tracking parameters and fragments.

    Args:
        url: Original URL

    Returns:
        Normalized URL without tracking parameters and fragments
    """
    # Fix HTML-encoded ampersands before parsing
    url = url.replace('&amp;', '&')

    parsed = urlparse(url)
    query_params = parse_qs(parsed.query)

    # Parameters to remove (case-insensitive check)
    params_to_remove = [
        "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
        "fbclid", "gclid", "msclkid", "mc_eid", "mc_cid",
        # Add any other common tracking parameters here
    ]

    # Filter out tracking parameters
    filtered_params = {
        k: v for k, v in query_params.items()
        if k.lower() not in params_to_remove
    }

    # Rebuild the URL without tracking params and fragment
    # Sort params for consistency
    new_query = urlencode(filtered_params, doseq=True)
    # Use urlunparse to reconstruct, ensuring scheme, netloc, path, etc., are preserved
    normalized = urlunparse((
        parsed.scheme,
        parsed.netloc,
        parsed.path,
        parsed.params,
        new_query,
        ''  # Remove fragment
    ))

    # Remove trailing slash if path is not just '/'
    if normalized.endswith('/') and urlparse(normalized).path != '/':
        normalized = normalized.rstrip('/')

    return normalized


def apply_site_specific_normalization(normalized_url: str, domain: str) -> str:
    """
    Apply site-specific normalization rules after general normalization.

    Args:
        normalized_url: Previously normalized URL
        domain: Domain of the website

    Returns:
        URL with site-specific normalization applied
    """
    if domain == "www.ceskenoviny.cz":
        # For ceskenoviny, check for all possible URL patterns
        # This expression matches both formats:
        # - /zpravy/2675120
        # - /zpravy/any-slug-here/2675120
        match = re.search(r"/zpravy/(?:[^/]+/)?(\d+)", normalized_url)
        if match:
            article_id = match.group(1)
            # Reconstruct the URL with just the scheme, netloc, and the canonical path
            parsed = urlparse(normalized_url)
            canonical_path = f"/zpravy/{article_id}"
            return urlunparse((parsed.scheme, parsed.netloc, canonical_path, '', '', ''))

    # Add rules for other sites here if needed
    # elif domain == "some.other.site":
    #     # Apply specific rules
    #     pass

    # Return the generally normalized URL if no specific rule matched or applied
    return normalized_url


def format_date(date_obj) -> str | None:
    """
    Format a date object as a string in the format YYYY-MM-DD HH:MM:SS.

    Args:
        date_obj: Date object to format

    Returns:
        Formatted date string
    """
    if date_obj is None:
        return None

    if hasattr(date_obj, 'strftime'):
        return date_obj.strftime("%Y-%m-%d %H:%M:%S")

    return str(date_obj)
