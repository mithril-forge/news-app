#!/usr/bin/env python3
"""
Models for the Czech News Crawler package.
Contains Pydantic models for article data and return types.
"""

from typing import Optional

from pydantic import BaseModel, Field


class Article(BaseModel):
    """Represents a single news article."""

    url: str = Field(..., description="Original crawled URL of the article")
    normalized_url: str = Field(..., description="Normalized URL used for deduplication")
    domain: str = Field(..., description="Domain of the news site")
    crawled_at: str = Field(..., description="Timestamp when the article was crawled")
    publish_date: Optional[str] = Field(None, description="Publication date of the article")
    language: Optional[str] = Field(None, description="Language of the article")
    title: str = Field(..., description="Title of the article")
    description: Optional[str] = Field(None, description="Meta description of the article")
    keywords: list[str] = Field(default=[], description="Keywords associated with the article")
    tags: list[str] = Field(default=[], description="Tags associated with the article")
    authors: list[str] = Field(default=[], description="Authors of the article")
    top_image_url: Optional[str] = Field(None, description="URL of the top image")
    text: str = Field(..., description="Full text content of the article")


class CrawlSummary(BaseModel):
    """Summary information about a crawl operation."""

    website: str = Field(..., description="Name of the website crawled")
    base_url: str = Field(..., description="Base URL of the website")
    articles_crawled: int = Field(..., description="Number of articles crawled")
    crawl_method: str = Field("newspaper.build", description="Method used for crawling")
    crawl_completed_at: str = Field(..., description="Timestamp when crawl was completed")
    date_filter: dict[str, Optional[str]] = Field(
        default_factory=lambda: {"start_date": None, "end_date": None},
        description="Date filters applied during crawling"
    )


class CrawlResult(BaseModel):
    """Complete result of a crawl operation across multiple sites."""

    articles_by_domain: dict[str, list[Article]] = Field(
        default_factory=dict,
        description="Dictionary mapping domains to lists of articles"
    )
    total_articles: int = Field(0, description="Total number of articles crawled")
    crawl_summaries: dict[str, CrawlSummary] = Field(
        default_factory=dict,
        description="Summaries of crawl operations by domain"
    )
    crawl_started_at: str = Field(..., description="Timestamp when the crawl operation started")
    crawl_completed_at: str = Field(..., description="Timestamp when the crawl operation completed")
    execution_time_seconds: float = Field(..., description="Total execution time in seconds")
