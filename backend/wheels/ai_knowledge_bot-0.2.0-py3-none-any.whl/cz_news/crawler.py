#!/usr/bin/env python3
"""
Czech News Article Crawler - Specialized crawler for Czech news websites.
Extracts and processes news articles from popular Czech news sites.
"""

import json
import logging
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from typing import Optional, Union
from urllib.parse import urlparse

import feedparser
from newspaper import Article, Config, build

from .models import Article as ArticleModel
from .models import CrawlResult, CrawlSummary
from .utils import apply_site_specific_normalization, format_date, normalize_url

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("cz_news.crawler")


class CzechNewsArticleCrawler:
    """Crawler specialized for Czech news websites."""

    # Default set of Czech news websites to crawl with RSS feed URLs
    # NOTE: good source for various czech media: https://cs.wikipedia.org/wiki/M%C3%A9dia_v_%C4%8Cesku
    DEFAULT_WEBSITES = {
        # NOTE: ceskenoviny under ČTK official news agency for the Czech Republic
        # NOTE: newspaper.article: works well, crawling: works good
        "ceskenoviny.cz": {
            "base_url": "https://www.ceskenoviny.cz",
            "rss_feeds": ["https://www.ceskenoviny.cz/sluzby/rss/zpravy.php"]
        },
        # FIXME: newspaper.article: last paragraph missing in .text
        # NOTE: crawling: works good with "/sekce" filter
        "novinky.cz": {
            "base_url": "https://www.novinky.cz",
            "rss_feeds": ["https://api-web.novinky.cz/v1/timelines/62baab43a1bac57b7436dc07?xml=rss"]
        },
        # NOTE: newspaper.article: works well,
        # crawling: works good, one problem with spotlight section
        #           either add filter for spotlight url or remove articles with no text
        "aktualne.cz": {
            "base_url": "https://www.aktualne.cz",
            # TODO: more rss feeds, maybe gather more, needs testing
            "rss_feeds": ["https://www.aktualne.cz/rss/"]
        },
        # NOTE: newspaper.article: works well, crawling: works good
        "denik.cz": {
            "base_url": "https://www.denik.cz",
            "rss_feeds": ["https://www.denik.cz/rss/zpravy.html"]
        },
        # NOTE: newspaper.article: works good, no meta keywords
        # crawling: good, one article with only 1 paragraph text
        "irozhlas.cz": {
            "base_url": "https://www.irozhlas.cz",
            "rss_feeds": [
                "https://www.irozhlas.cz/rss/irozhlas",
            ]
        },
        # crawling: behind crawlwall?
        # NOTE: newspaper.article: two paragraphs missing in .text, but other article worked perfectly
        # "seznamzpravy.cz": {"base_url": "https://www.seznamzpravy.cz"},
        # ---
        # NOTE: I wouldn't invest too much energy into bypassing adwalls/paywalls, lots of other sources
        # ---
        # NOTE: newspaper.article: works good, some additional links bluff at the end of .text
        # NOTE: isport.blesk.cz not working so good, maybe add filter?
        # FIXME: deal with blesk.cz later
        # "blesk.cz": {"base_url": "https://www.blesk.cz"},
        # NOTE: newspaper.article: works good, but some articles are behind a paywall
        # "reflex.cz": {"base_url": "https://www.reflex.cz"},
        # FIXME: newspaper.article() is blocked by adwall
        # "lidovky.cz": {"base_url": "https://www.lidovky.cz"},
        # FIXME: newspaper.article() is blocked by adwall
        # "idnes.cz": {"base_url": "https://www.idnes.cz"},
        # FIXME: newspaper.article() only gets the first paragraph, blocked by paywall
        # "hn.cz/ihned.cz": {"base_url": "https://www.hn.cz"},
    }

    # URL patterns to avoid (login pages, search results, etc.)
    IGNORE_PATTERNS = [
        # Common non-article paths
        "/login", "/prihlaseni", "/registrace", "/hledej", "/hledani", "/vyhledavani",
        "/search", "/anketa", "/diskuse", "/api", "/rss", "/promo", "/reklama",
        "/podcasty", "/inzerce", "/obrazem", "/galerie", "/kontakty", "/lifestyle",
        "/video", "/audiovizual", "/kariera", "/predplatne", "/mobilni-aplikace",
        "/autori", "/redakce", "/rss-export",
        # Specific listing/tag patterns observed
        "/sekce/", "/tag/", "/tema/", "/rubrika/", "/autor/", "/osobnost/", "/klicove-slovo/",
        "/l~i:keyword:", # aktualne.cz specific
        # File extensions
        ".jpg", ".png", ".pdf", ".gif", ".mp3", ".mp4", ".zip", ".xml",
        # Protocols/Schemes to ignore
        "javascript:", "mailto:", "tel:", "webcal:", "whatsapp:",
    ]

    # Minimum text length for an article to be considered valid
    MIN_ARTICLE_TEXT_LENGTH = 150

    def __init__(
        self,
        output_dir: Optional[str] = None,
        websites: Optional[dict[str, dict[str, Union[str, list[str]]]]] = None,
        max_articles_per_site: Optional[int] = None,
        delay_between_requests: float = 2.0,
        timeout: int = 10,
        newspaper_config: Optional[Config] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        recent_days: Optional[int] = None,
        time_delta: Optional[timedelta] = None,
        save_to_disk: bool = False,
        max_iterations: int = 100,
    ):
        """
        Initialize the Czech news crawler.

        Args:
            output_dir: Base directory to save downloaded content (only used if save_to_disk is True)
            websites: Dictionary of websites to crawl with their base URLs
            max_articles_per_site: Maximum number of articles to download per website (default: unlimited)
            delay_between_requests: Delay between requests in seconds
            timeout: Request timeout in seconds
            newspaper_config: Configuration for newspaper library
            start_date: Start date for article filtering
            end_date: End date for article filtering
            recent_days: Number of recent days to get articles from
            save_to_disk: Whether to save articles to disk
            max_iterations: Maximum number of article URLs to process per site to prevent infinite loops
        """
        self.output_dir = output_dir
        self.websites = websites or self.DEFAULT_WEBSITES
        self.max_articles_per_site = max_articles_per_site
        self.delay = delay_between_requests
        self.timeout = timeout
        self.save_to_disk = save_to_disk
        self.max_iterations = max_iterations

        # Initialize newspaper config with settings optimized for Czech news sites
        self.newspaper_config = newspaper_config or Config()
        # Legit browser user agent to avoid bot detection
        self.newspaper_config.browser_user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36'
        self.newspaper_config.request_timeout = self.timeout
        self.newspaper_config.thread_timeout_seconds = self.timeout
        self.newspaper_config.fetch_images = True
        self.newspaper_config.memorize_articles = False  # Don't memorize to avoid memory issues
        self.newspaper_config.language = 'cs'  # Set language to Czech

        # Add date filtering options
        self.start_date = start_date

        # Priority: time_delta > recent_days > explicit date range

        if time_delta is not None:
            # If time_delta is specified, set end_date to today and start_date according to timedelta
            self.end_date = datetime.today()
            self.start_date = self.end_date - time_delta
        elif recent_days is not None:
            # If recent_days is specified, set end_date to today and start_date accordingly
            self.end_date = datetime.today()
            self.start_date = self.end_date - timedelta(days=recent_days)
        else:
            self.end_date = end_date

        # Track crawled URLs for this session to avoid duplicates
        self.crawled_urls = set()
        # Track crawled *normalized* URLs for this session to avoid duplicates
        self.crawled_normalized_urls = set()

        # Create output directory structure if saving to disk
        if self.save_to_disk and self.output_dir:
            for website_name in self.websites:
                website_dir = os.path.join(self.output_dir, website_name)
                os.makedirs(website_dir, exist_ok=True)

    def is_within_date_range(self, pub_date: Optional[datetime]) -> bool:
        """
        Check if publication date falls within specified date range.

        Args:
            pub_date: Publication date to check

        Returns:
            Boolean indicating if date is within range
        """
        # If no date filtering is enabled or pub_date is None, accept all
        if (self.start_date is None and self.end_date is None) or pub_date is None:
            return True
        # Check start date
        if self.start_date and pub_date < self.start_date:
            return False
        # Check end date
        if self.end_date and pub_date > self.end_date:
            return False
        return True

    def download_and_process_article(
        self,
        url: str,
        website_name: str,
        article_index: int,
    ) -> Optional[tuple[Optional[str], Optional[ArticleModel]]]:
        """
        Download and process a news article. Includes normalization and validation.
        Applies general and site-specific normalization for duplicate checking.

        Args:
            url: URL of the article to download
            website_name: Name of the website
            article_index: Index of the article for naming

        Returns:
            Tuple of (file path if saved to disk, article model) or None if processing failed
        """
        # Initial normalization (params, fragments)
        temp_normalized_url = normalize_url(url)
        domain = urlparse(url).netloc # Get domain from original URL

        # Apply site-specific normalization rules for a more robust check
        final_normalized_url = apply_site_specific_normalization(temp_normalized_url, domain)

        # Skip if already crawled (using final normalized URL)
        # This set now stores the most canonical form we can determine
        if final_normalized_url in self.crawled_normalized_urls:
            logger.debug(f"Skipping already processed normalized URL: {final_normalized_url} (Original: {url})")
            return None
        # Add the final, potentially site-specific, normalized URL to the global set
        self.crawled_normalized_urls.add(final_normalized_url)

        # Create article using newspaper library (use original URL for download)
        article = Article(url, config=self.newspaper_config)
        try:
            article.download()
        except Exception as e:
            logger.error(f"Failed to download article {url}: {e}")
            return None

        # Check if download was successful
        if not article.html or len(article.html) < 500:  # Too small to be an article
            logger.warning(f"Failed to download or too small: {url}")
            return None

        # Parse the article
        try:
            article.parse()
        except Exception as e:
            logger.error(f"Failed to parse article {url}: {e}")
            return None

        # --- Post-parsing Validation ---

        # 1. Check text length
        if not article.text or len(article.text) < self.MIN_ARTICLE_TEXT_LENGTH:
            logger.warning(f"Skipping article - text too short ({len(article.text)} chars) or missing: {url}")
            return None

        # 2. Check publish date against filters
        # Remove timezone info from publish date, this ensures we always
        # assume the scraped date is in local time when comparing
        article.publish_date = article.publish_date.replace(tzinfo=None) if article.publish_date else None
        if not self.is_within_date_range(article.publish_date):
            logger.info(f"Skipping article from {article.publish_date} - outside date range: {url}")
            return None

        # --- Create Article Model ---
        article_model = ArticleModel(
            url=url,
            normalized_url=final_normalized_url,
            domain=domain,
            crawled_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            publish_date=format_date(article.publish_date),
            language=article.meta_lang,
            title=article.title,
            description=article.meta_description,
            keywords=list(article.meta_keywords) if (article.meta_keywords and article.meta_keywords != [""]) else [],
            tags=list(article.tags) if article.tags else [],
            authors=list(article.authors) if article.authors else [],
            top_image_url=article.top_image,
            text=article.text,
        )

        # --- Save Article to Disk if Required ---
        metadata_path = None
        if self.save_to_disk and self.output_dir:
            # Generate a unique filename
            file_base = f"{article_index:04d}"
            metadata_name = f"{file_base}-metadata.json"

            # Save metadata to disk
            output_dir = os.path.join(self.output_dir, website_name)
            metadata_path = os.path.join(output_dir, metadata_name)
            metadata = article_model.model_dump()
            metadata_path = os.path.join(output_dir, metadata_name)
            try:
                with open(metadata_path, "w", encoding="utf-8") as f:
                    json.dump(metadata, f, ensure_ascii=False, indent=2)
            except Exception as e:
                logger.error(f"Failed to write metadata file {metadata_path}: {e}")

        logger.info(f"Processed article {article_index}: {article.title} ({url})")
        return metadata_path, article_model

    def crawl_website(self, website_name: str, config: dict[str, Union[str, list[str]]]) -> tuple[list[ArticleModel], CrawlSummary]:
        """
        Crawl a specific website using RSS feeds for article discovery.

        Args:
            website_name: Name of the website
            config: Configuration for the website (contains base_url and rss_feeds)

        Returns:
            Tuple of (list of article models, crawl summary)
        """
        base_url = config["base_url"]
        rss_feeds = config.get("rss_feeds", [])

        if not rss_feeds:
            logger.warning(f"No RSS feeds configured for {website_name}, falling back to newspaper.build()")
            return self._crawl_website_fallback(website_name, config)

        logger.info(f"Crawling website: {website_name} ({base_url}) using RSS feeds")

        article_count = 0
        articles = []
        iteration_count = 0
        # Track *normalized* URLs processed for this specific site run to avoid duplicates
        processed_normalized_urls_for_site = set()

        # Collect all article URLs from RSS feeds
        all_article_urls = []

        for rss_url in rss_feeds:
            try:
                logger.info(f"Parsing RSS feed: {rss_url}")
                feed = feedparser.parse(rss_url)

                if feed.bozo:
                    logger.warning(f"RSS feed has parsing issues: {rss_url} - {feed.bozo_exception}")

                if not feed.entries:
                    logger.warning(f"No entries found in RSS feed: {rss_url}")
                    continue

                logger.info(f"Found {len(feed.entries)} entries in RSS feed: {rss_url}")

                for entry in feed.entries:
                    if hasattr(entry, 'link'):
                        all_article_urls.append(entry.link)
                    elif hasattr(entry, 'guid'):
                        all_article_urls.append(entry.guid)

            except Exception as e:
                logger.error(f"Error parsing RSS feed {rss_url}: {e}")
                continue

        if not all_article_urls:
            logger.warning(f"No article URLs found in any RSS feeds for {website_name}")
            return [], CrawlSummary(
                website=website_name,
                base_url=base_url,
                articles_crawled=0,
                crawl_method="rss_feeds",
                crawl_completed_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                date_filter={
                    "start_date": format_date(self.start_date) if self.start_date else None,
                    "end_date": format_date(self.end_date) if self.end_date else None,
                }
            )

        logger.info(f"Found {len(all_article_urls)} total article URLs from RSS feeds for {website_name}")

        # Process each article URL
        for original_url in all_article_urls:
            iteration_count += 1
            normalized_url = normalize_url(original_url)

            # Basic URL filtering (check original URL against ignore patterns)
            if any(pattern in original_url for pattern in self.IGNORE_PATTERNS):
                logger.debug(f"Skipping ignored pattern URL: {original_url}")
                continue

            # Avoid processing the same *normalized* URL multiple times within this site crawl
            if normalized_url in processed_normalized_urls_for_site:
                logger.debug(f"Skipping already processed normalized URL within site run: {normalized_url} (Original: {original_url})")
                continue
            processed_normalized_urls_for_site.add(normalized_url)

            # Check maximum limit for the site (based on successfully processed articles)
            if self.max_articles_per_site is not None and article_count >= self.max_articles_per_site:
                logger.info(f"Reached max articles per site ({self.max_articles_per_site}) for {website_name}")
                break

            # Check maximum iterations to prevent infinite loops
            if iteration_count >= self.max_iterations:
                logger.warning(f"Reached max iterations ({self.max_iterations}) for {website_name}. "
                             f"Processed {article_count} articles successfully. "
                             f"Consider adjusting max_iterations or date filters to avoid infinite loops.")
                break

            # Log progress at intervals to track iterations
            if iteration_count % 25 == 0:
                logger.info(f"Processed {iteration_count} articles from {website_name}, "
                          f"successfully extracted {article_count} articles")

            # Download and process article (using existing method, passing original URL)
            # Pass article_count + 1 for indexing
            result = None  # Initialize result
            try:
                # Pass the *original* URL to download_and_process_article
                # Normalization happens inside that function now for the global check
                result = self.download_and_process_article(original_url, website_name, article_count + 1)
            except Exception as e:
                logger.error(f"Error processing article {original_url}: {e}")

            if result:
                _, article_model = result
                if article_model:
                    articles.append(article_model)
                    article_count += 1  # Increment only if successfully processed

            # Respect crawl delay after each attempt (success or fail)
            time.sleep(self.delay)

        logger.info(f"Finished crawling {website_name}. Total articles processed: {article_count}")

        # Create crawl summary
        crawl_summary = CrawlSummary(
            website=website_name,
            base_url=base_url,
            articles_crawled=article_count,
            crawl_method="rss_feeds",
            crawl_completed_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            date_filter={
                "start_date": format_date(self.start_date) if self.start_date else None,
                "end_date": format_date(self.end_date) if self.end_date else None,
            }
        )

        # Save crawl summary for this website if saving to disk
        if self.save_to_disk and self.output_dir:
            output_dir = os.path.join(self.output_dir, website_name)
            summary_path = os.path.join(output_dir, "crawl_summary.json")

            with open(summary_path, "w", encoding="utf-8") as f:
                json.dump(crawl_summary.model_dump(), f, ensure_ascii=False, indent=2)

        return articles, crawl_summary

    def _crawl_website_fallback(self, website_name: str, config: dict[str, Union[str, list[str]]]) -> tuple[list[ArticleModel], CrawlSummary]:
        """
        Fallback method using newspaper.build() when RSS feeds are not available.

        Args:
            website_name: Name of the website
            config: Configuration for the website (contains base_url)

        Returns:
            Tuple of (list of article models, crawl summary)
        """
        base_url = config["base_url"]
        logger.info(f"Crawling website: {website_name} ({base_url}) using newspaper.build()")

        article_count = 0
        articles = []
        iteration_count = 0
        # Track *normalized* URLs processed for this specific site run to avoid duplicates
        processed_normalized_urls_for_site = set()

        try:
            # Use newspaper.build to discover articles
            source = build(base_url, config=self.newspaper_config)
            logger.info(f"Found {len(source.articles)} potential articles on {website_name}")

            for article_obj in source.articles:
                iteration_count += 1
                original_url = article_obj.url
                normalized_url = normalize_url(original_url)

                # Basic URL filtering (check original URL against ignore patterns)
                if any(pattern in original_url for pattern in self.IGNORE_PATTERNS):
                    logger.debug(f"Skipping ignored pattern URL: {original_url}")
                    continue

                # Avoid processing the same *normalized* URL multiple times within this site crawl
                if normalized_url in processed_normalized_urls_for_site:
                    logger.debug(f"Skipping already processed normalized URL within site run: {normalized_url} (Original: {original_url})")
                    continue
                processed_normalized_urls_for_site.add(normalized_url)

                # Check maximum limit for the site (based on successfully processed articles)
                if self.max_articles_per_site is not None and article_count >= self.max_articles_per_site:
                    logger.info(f"Reached max articles per site ({self.max_articles_per_site}) for {website_name}")
                    break

                # Check maximum iterations to prevent infinite loops
                if iteration_count >= self.max_iterations:
                    logger.warning(f"Reached max iterations ({self.max_iterations}) for {website_name}. "
                                 f"Processed {article_count} articles successfully. "
                                 f"Consider adjusting max_iterations or date filters to avoid infinite loops.")
                    break

                # Log progress at intervals to track iterations
                if iteration_count % 25 == 0:
                    logger.info(f"Processed {iteration_count} articles from {website_name}, "
                              f"successfully extracted {article_count} articles")

                # Download and process article (using existing method, passing original URL)
                # Pass article_count + 1 for indexing
                result = None  # Initialize result
                try:
                    # Pass the *original* URL to download_and_process_article
                    # Normalization happens inside that function now for the global check
                    result = self.download_and_process_article(original_url, website_name, article_count + 1)
                except Exception as e:
                    logger.error(f"Error processing article {original_url}: {e}")

                if result:
                    _, article_model = result
                    if article_model:
                        articles.append(article_model)
                        article_count += 1  # Increment only if successfully processed

                # Respect crawl delay after each attempt (success or fail)
                time.sleep(self.delay)

        except Exception as e:
            logger.error(f"Error building or processing source {website_name} ({base_url}): {e}")

        logger.info(f"Finished crawling {website_name}. Total articles processed: {article_count}")

        # Create crawl summary
        crawl_summary = CrawlSummary(
            website=website_name,
            base_url=base_url,
            articles_crawled=article_count,
            crawl_method="newspaper.build",
            crawl_completed_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            date_filter={
                "start_date": format_date(self.start_date) if self.start_date else None,
                "end_date": format_date(self.end_date) if self.end_date else None,
            }
        )

        # Save crawl summary for this website if saving to disk
        if self.save_to_disk and self.output_dir:
            output_dir = os.path.join(self.output_dir, website_name)
            summary_path = os.path.join(output_dir, "crawl_summary.json")

            with open(summary_path, "w", encoding="utf-8") as f:
                json.dump(crawl_summary.model_dump(), f, ensure_ascii=False, indent=2)

        return articles, crawl_summary

    def run(self) -> CrawlResult:
        """
        Run the crawler on all configured websites in parallel.

        Returns:
            CrawlResult object containing articles by domain and crawl summaries
        """
        start_time = time.time()
        logger.info(f"Starting Czech news crawler for {len(self.websites)} websites in parallel")

        # Log date filter settings if specified
        if self.start_date or self.end_date:
            date_range = f"from {self.start_date.strftime('%Y-%m-%d') if self.start_date else 'earliest'} " \
                         f"to {self.end_date.strftime('%Y-%m-%d') if self.end_date else 'latest'}"
            logger.info(f"Date filter active: {date_range}")

        articles_by_domain = {}
        summaries = {}

        # Use ThreadPoolExecutor for parallel execution
        # Each worker will crawl a different website
        max_workers = len(self.websites)
        logger.info(f"Using up to {max_workers} parallel workers.")

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit crawl_website tasks for each website
            future_to_website = {executor.submit(self.crawl_website, name, config): name
                                 for name, config in self.websites.items()}

            for future in as_completed(future_to_website):
                website_name = future_to_website[future]
                try:
                    articles, summary = future.result()
                    articles_by_domain[website_name] = articles
                    summaries[website_name] = summary
                    logger.info(f"Completed crawling {website_name}: {len(articles)} articles")
                except Exception as exc:
                    logger.error(f"{website_name} generated an exception during crawling: {exc}")
                    articles_by_domain[website_name] = []
                    # Create an empty summary for failed sites
                    summaries[website_name] = CrawlSummary(
                        website=website_name,
                        base_url=self.websites[website_name]["base_url"],
                        articles_crawled=0,
                        crawl_method="newspaper.build",
                        crawl_completed_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        date_filter={
                            "start_date": format_date(self.start_date) if self.start_date else None,
                            "end_date": format_date(self.end_date) if self.end_date else None,
                        }
                    )

        # Calculate and log statistics
        total_articles = sum(len(articles) for articles in articles_by_domain.values())
        elapsed_time = time.time() - start_time

        logger.info(f"Crawler completed in {elapsed_time:.2f} seconds")
        logger.info(f"Total articles crawled: {total_articles}")

        # Sort results alphabetically for consistent logging
        for website in sorted(articles_by_domain.keys()):
            count = len(articles_by_domain[website])
            logger.info(f"  - {website}: {count} articles")

        # Create the final result object
        result = CrawlResult(
            articles_by_domain=articles_by_domain,
            total_articles=total_articles,
            crawl_summaries=summaries,
            crawl_started_at=datetime.fromtimestamp(start_time).strftime("%Y-%m-%d %H:%M:%S"),
            crawl_completed_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            execution_time_seconds=elapsed_time
        )

        return result


def crawl_czech_news(
    output_dir: Optional[str] = None,
    websites: Optional[list[str]] = None,
    max_articles_per_site: Optional[int] = None,
    delay: float = 2.0,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    recent_days: Optional[int] = None,
    time_delta: Optional[timedelta] = None,
    save_to_disk: bool = False,
    max_iterations: int = 100,
) -> CrawlResult:
    """
    Crawl Czech news websites and return the results.

    This is the main public function for the cz_news package.

    Args:
        output_dir: Directory to save crawled data (only used if save_to_disk is True)
        websites: List of specific websites to crawl (default: all supported sites)
        max_articles_per_site: Maximum number of articles per website (default: unlimited)
        delay: Delay between requests in seconds
        start_date: Start date for article filtering (format: YYYY-MM-DD)
        end_date: End date for article filtering (format: YYYY-MM-DD)
        recent_days: Get articles from the last N days (overrides start-date and end-date)
        time_delta: Get articles from the time period defined by timedelta (overridden by recent_days)
        save_to_disk: Whether to save articles to disk
        max_iterations: Maximum number of article URLs to process per site to prevent infinite loops

    Returns:
        CrawlResult object containing the crawled articles and summaries
    """
    # Parse date strings to datetime objects
    start_datetime = None
    end_datetime = None

    if start_date:
        try:
            start_datetime = datetime.strptime(start_date, "%Y-%m-%d")
        except ValueError:
            logger.error("Invalid start-date format. Use YYYY-MM-DD")
            # Continue with None

    if end_date:
        try:
            end_datetime = datetime.strptime(end_date, "%Y-%m-%d")
        except ValueError:
            logger.error("Invalid end-date format. Use YYYY-MM-DD")
            # Continue with None

    # Create the crawler
    crawler = CzechNewsArticleCrawler(
        output_dir=output_dir,
        max_articles_per_site=max_articles_per_site,
        delay_between_requests=delay,
        start_date=start_datetime,
        end_date=end_datetime,
        recent_days=recent_days,
        time_delta=time_delta,
        save_to_disk=save_to_disk,
        max_iterations=max_iterations,
    )

    # Filter websites if specified
    if websites:
        filtered_websites = {}
        for website in websites:
            if website in crawler.DEFAULT_WEBSITES:
                filtered_websites[website] = crawler.DEFAULT_WEBSITES[website]
            else:
                logger.warning(f"Unknown website: {website}. Ignoring.")

        if filtered_websites:
            crawler.websites = filtered_websites
        else:
            logger.error("No valid websites specified.")
            # Return empty result instead of exiting
            return CrawlResult(
                articles_by_domain={},
                total_articles=0,
                crawl_summaries={},
                crawl_started_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                crawl_completed_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                execution_time_seconds=0
            )

    # Start crawling and return the result
    return crawler.run()
