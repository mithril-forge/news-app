#!/usr/bin/env python3
"""
Command-line interface for the Czech News Crawler.
"""

import argparse
import json
import logging
import sys
from datetime import timedelta

from .crawler import crawl_czech_news

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("cz_news.cli")


def main():
    """
    Main entry point for the command-line interface.
    """
    parser = argparse.ArgumentParser(description="Czech News Article Crawler")

    parser.add_argument(
        "--output-dir",
        default="raw/cz_news",
        help="Directory to save crawled data (default: raw/cz_news)"
    )
    parser.add_argument(
        "--websites",
        nargs="+",
        help="Specific websites to crawl (default: all supported sites)"
    )
    parser.add_argument(
        "--max-articles-per-site",
        type=int,
        default=None,
        help="Maximum number of articles per website (default: unlimited)"
    )
    parser.add_argument(
        "--delay",
        type=float,
        default=2.0,
        help="Delay between requests in seconds (default: 2.0)"
    )
    # Add date filtering arguments
    parser.add_argument(
        "--start-date",
        help="Start date for article filtering (format: YYYY-MM-DD)"
    )
    parser.add_argument(
        "--end-date",
        help="End date for article filtering (format: YYYY-MM-DD)"
    )
    parser.add_argument(
        "--recent-days",
        type=int,
        help="Get articles from the last N days (overrides start-date, end-date, and time-delta)"
    )
    parser.add_argument(
        "--time-delta",
        type=str,
        help="Get articles from a time period defined by a string like '1d2h30m' (1 day, 2 hours, 30 minutes). Overridden by recent-days."
    )
    parser.add_argument(
        "--max-iterations",
        type=int,
        default=100,
        help="Maximum number of article URLs to process per site to prevent infinite loops (default: 100)"
    )
    parser.add_argument(
        "--max-consecutive-failures",
        type=int,
        default=5,
        help="Maximum number of consecutive failures before stopping site crawl (default: 5)"
    )
    parser.add_argument(
        "--json-out",
        help="Optional path to save results as JSON (includes all metadata but no HTML content)"
    )

    args = parser.parse_args()

    try:
        # Parse time-delta if provided
        time_delta = None
        if args.time_delta and not args.recent_days:  # Only process if recent_days not specified
            try:
                # Parse the time delta string (format like '1d2h30m' for 1 day, 2 hours, 30 minutes)
                td_str = args.time_delta
                days, hours, minutes = 0, 0, 0

                # Extract days
                if 'd' in td_str:
                    days_part = td_str.split('d')[0]
                    days = int(days_part.strip())
                    td_str = td_str.split('d')[1]

                # Extract hours
                if 'h' in td_str:
                    hours_part = td_str.split('h')[0]
                    hours = int(hours_part.strip())
                    td_str = td_str.split('h')[1]

                # Extract minutes
                if 'm' in td_str:
                    minutes_part = td_str.split('m')[0]
                    minutes = int(minutes_part.strip())

                time_delta = timedelta(days=days, hours=hours, minutes=minutes)
                logger.info(f"Using time delta: {days} days, {hours} hours, {minutes} minutes")
            except Exception as e:
                logger.error(f"Error parsing time-delta: {e}. Format should be like '1d2h30m'.")
                return 1

        # When running from CLI, always save to disk
        result = crawl_czech_news(
            output_dir=args.output_dir,
            websites=args.websites,
            max_articles_per_site=args.max_articles_per_site,
            delay=args.delay,
            start_date=args.start_date,
            end_date=args.end_date,
            recent_days=args.recent_days,
            time_delta=time_delta,
            save_to_disk=True,
            max_iterations=args.max_iterations,
            max_consecutive_failures=args.max_consecutive_failures,
        )

        # Save JSON output if requested
        if args.json_out:
            # Exclude HTML content to keep the file size reasonable
            json_result = result.model_dump(exclude={"articles_by_domain": {"__all__": {"html"}}})

            with open(args.json_out, "w", encoding="utf-8") as f:
                json.dump(json_result, f, ensure_ascii=False, indent=2)
                logger.info(f"Saved JSON results to {args.json_out}")

        return 0

    except KeyboardInterrupt:
        logger.info("Crawling process interrupted by user")
        return 130  # Standard exit code for SIGINT
    except Exception as e:
        logger.error(f"Error: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
